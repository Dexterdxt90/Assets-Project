import sqlite3
from typing import List, Optional
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="Adcos Inventário API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DB_NAME = "inventario.db"

DEFAULT_TIPOS = [
    "celulares", "iPads", "Notebooks", "impressoras",
    "Desktop", "Monitor", "Smartphone", "Tablet",
    "Nobreak", "Servidor", "Switch / Roteador", "Periférico", "Outro"
]

DEFAULT_LOCALIDADES = [
    "Lojas", "Estoque", "Escritório (Brands)", "Serra-ES",
    "Matriz / Sede", "Filial SP", "Filial RJ", "Fábrica",
    "Centro de Distribuição", "Home Office", "Terceirizado"
]

DEFAULT_STATUS = [
    "Em Estoque", "Em Uso", "Em Manutenção", "Descartado"
]

DADOS_INICIAIS = [
    {"id": 1, "categoria": "celulares", "modelo": "Samsung Galaxy S22", "numero_serie": "SN-CEL-001", "localizacao": "Lojas", "status": "Em Uso"},
    {"id": 2, "categoria": "celulares", "modelo": "iPhone 13", "numero_serie": "SN-CEL-002", "localizacao": "Estoque", "status": "Em Estoque"},
    {"id": 3, "categoria": "iPads", "modelo": "iPad Air 5", "numero_serie": "SN-PAD-001", "localizacao": "Escritório (Brands)", "status": "Em Uso"},
    {"id": 4, "categoria": "Notebooks", "modelo": "Dell Latitude 5420", "numero_serie": "SN-NTB-010", "localizacao": "Serra-ES", "status": "Em Uso"},
    {"id": 5, "categoria": "Notebooks", "modelo": "ThinkPad L14", "numero_serie": "SN-NTB-011", "localizacao": "Estoque", "status": "Em Estoque"},
    {"id": 6, "categoria": "impressoras", "modelo": "HP LaserJet M404dn", "numero_serie": "SN-IMP-005", "localizacao": "Lojas", "status": "Em Uso"},
    {"id": 7, "categoria": "impressoras", "modelo": "Epson EcoTank L3250", "numero_serie": "SN-IMP-006", "localizacao": "Escritório (Brands)", "status": "Em Uso"},
    {"id": 8, "categoria": "iPads", "modelo": "iPad Pro 11", "numero_serie": "SN-PAD-002", "localizacao": "Serra-ES", "status": "Em Estoque"}
]

def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS ativos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            data_movimentacao TEXT,
            numero_serie TEXT NOT NULL,
            patrimonio TEXT,
            nome_ativo TEXT,
            fabricante TEXT,
            tipo TEXT NOT NULL,
            localidade TEXT NOT NULL,
            localizacao_setor TEXT,
            status TEXT NOT NULL,
            contrato TEXT,
            usuario_antigo TEXT,
            centro_custo_antigo TEXT,
            usuario_atual TEXT,
            centro_custo_atual TEXT,
            responsavel_cc TEXT,
            observacoes TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS tipos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT UNIQUE NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS localidades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT UNIQUE NOT NULL
        )
    """)

    cursor.execute("SELECT COUNT(*) FROM tipos")
    if cursor.fetchone()[0] == 0:
        cursor.executemany("INSERT INTO tipos (nome) VALUES (?)", [(t,) for t in DEFAULT_TIPOS])

    cursor.execute("SELECT COUNT(*) FROM localidades")
    if cursor.fetchone()[0] == 0:
        cursor.executemany("INSERT INTO localidades (nome) VALUES (?)", [(l,) for l in DEFAULT_LOCALIDADES])

    cursor.execute("SELECT COUNT(*) FROM ativos")
    if cursor.fetchone()[0] == 0:
        for item in DADOS_INICIAIS:
            cursor.execute("""
                INSERT INTO ativos (id, tipo, nome_ativo, numero_serie, localidade, status)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (item["id"], item["categoria"], item["modelo"], item["numero_serie"], item["localizacao"], item["status"]))

    conn.commit()
    conn.close()

init_db()

class AtivoCreate(BaseModel):
    data_movimentacao: Optional[str] = None
    numero_serie: str
    patrimonio: Optional[str] = None
    nome_ativo: Optional[str] = None
    fabricante: Optional[str] = None
    tipo: str
    localidade: str
    localizacao_setor: Optional[str] = None
    status: str
    contrato: Optional[str] = None
    usuario_antigo: Optional[str] = None
    centro_custo_antigo: Optional[str] = None
    usuario_atual: Optional[str] = None
    centro_custo_atual: Optional[str] = None
    responsavel_cc: Optional[str] = None
    observacoes: Optional[str] = None

class OpcaoItem(BaseModel):
    nome: str

@app.get("/api/tipos")
def listar_tipos():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT nome FROM tipos ORDER BY nome ASC")
    rows = cursor.fetchall()
    conn.close()
    return [row[0] for row in rows]

@app.post("/api/tipos", status_code=201)
def criar_tipo(item: OpcaoItem):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO tipos (nome) VALUES (?)", (item.nome.strip(),))
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        raise HTTPException(status_code=400, detail="Tipo já existe")
    conn.close()
    return {"message": "Tipo adicionado com sucesso"}

@app.get("/api/localidades")
def listar_localidades():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT nome FROM localidades ORDER BY nome ASC")
    rows = cursor.fetchall()
    conn.close()
    return [row[0] for row in rows]

@app.post("/api/localidades", status_code=201)
def criar_localidade(item: OpcaoItem):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO localidades (nome) VALUES (?)", (item.nome.strip(),))
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        raise HTTPException(status_code=400, detail="Localidade já existe")
    conn.close()
    return {"message": "Localidade adicionada com sucesso"}

@app.get("/api/status")
def listar_status():
    return DEFAULT_STATUS

@app.get("/api/opcoes")
def obter_todas_opcoes():
    return {
        "tipos": listar_tipos(),
        "localidades": listar_localidades(),
        "status": DEFAULT_STATUS
    }

@app.get("/api/ativos")
@app.get("/api/dispositivos")
def listar_ativos(tipo: Optional[str] = None, localidade: Optional[str] = None, busca: Optional[str] = None):
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    query = "SELECT * FROM ativos WHERE 1=1"
    params = []

    if tipo and tipo.lower() not in ["todos", "todos os tipos", "todas"]:
        query += " AND LOWER(tipo) = LOWER(?)"
        params.append(tipo)

    if localidade and localidade.lower() not in ["todas", "todas as localidades", "todos"]:
        query += " AND LOWER(localidade) = LOWER(?)"
        params.append(localidade)

    if busca:
        query += " AND (numero_serie LIKE ? OR patrimonio LIKE ? OR nome_ativo LIKE ? OR usuario_atual LIKE ? OR fabricante LIKE ?)"
        term = f"%{busca}%"
        params.extend([term, term, term, term, term])

    query += " ORDER BY id DESC"

    cursor.execute(query, params)
    rows = cursor.fetchall()
    conn.close()

    resultado = []
    for row in rows:
        d = dict(row)
        d["categoria"] = d["tipo"]
        d["modelo"] = d["nome_ativo"] or ""
        d["localizacao"] = d["localidade"]
        resultado.append(d)

    return resultado

@app.get("/api/stats")
def obter_estatisticas():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM ativos")
    total = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM ativos WHERE status = 'Em Uso'")
    uso = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM ativos WHERE status = 'Em Estoque'")
    estoque = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM ativos WHERE status = 'Em Manutenção'")
    manutencao = cursor.fetchone()[0]

    conn.close()
    return {"total": total, "uso": uso, "estoque": estoque, "manutencao": manutencao}

@app.post("/api/ativos", status_code=201)
@app.post("/api/dispositivos", status_code=201)
def criar_ativo(ativo: AtivoCreate):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO ativos (
            data_movimentacao, numero_serie, patrimonio, nome_ativo, fabricante,
            tipo, localidade, localizacao_setor, status, contrato,
            usuario_antigo, centro_custo_antigo, usuario_atual, centro_custo_atual,
            responsavel_cc, observacoes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        ativo.data_movimentacao, ativo.numero_serie, ativo.patrimonio, ativo.nome_ativo,
        ativo.fabricante, ativo.tipo, ativo.localidade, ativo.localizacao_setor,
        ativo.status, ativo.contrato, ativo.usuario_antigo, ativo.centro_custo_antigo,
        ativo.usuario_atual, ativo.centro_custo_atual, ativo.responsavel_cc, ativo.observacoes
    ))

    ativo_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return {"id": ativo_id, "message": "Ativo cadastrado com sucesso!"}

@app.put("/api/ativos/{ativo_id}")
@app.put("/api/dispositivos/{ativo_id}")
def atualizar_ativo(ativo_id: int, ativo: AtivoCreate):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute("""
        UPDATE ativos SET
            data_movimentacao = ?, numero_serie = ?, patrimonio = ?, nome_ativo = ?,
            fabricante = ?, tipo = ?, localidade = ?, localizacao_setor = ?,
            status = ?, contrato = ?, usuario_antigo = ?, centro_custo_antigo = ?,
            usuario_atual = ?, centro_custo_atual = ?, responsavel_cc = ?, observacoes = ?
        WHERE id = ?
    """, (
        ativo.data_movimentacao, ativo.numero_serie, ativo.patrimonio, ativo.nome_ativo,
        ativo.fabricante, ativo.tipo, ativo.localidade, ativo.localizacao_setor,
        ativo.status, ativo.contrato, ativo.usuario_antigo, ativo.centro_custo_antigo,
        ativo.usuario_atual, ativo.centro_custo_atual, ativo.responsavel_cc, ativo.observacoes,
        ativo_id
    ))

    conn.commit()
    conn.close()
    return {"message": "Ativo atualizado com sucesso!"}

@app.delete("/api/ativos/{ativo_id}")
@app.delete("/api/dispositivos/{ativo_id}")
def deletar_ativo(ativo_id: int):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM ativos WHERE id = ?", (ativo_id,))
    conn.commit()
    conn.close()
    return {"message": "Ativo excluído com sucesso"}