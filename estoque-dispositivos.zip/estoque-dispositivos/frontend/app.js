const API_URL = window.location.origin.includes("file:") 
    ? "http://127.0.0.1:8000/api" 
    : window.location.origin + "/api";

let filtroTipoAtual = "todos";
let filtroLocalidadeAtual = "todas";
let chartStatusInstance = null;
let chartLocalizacaoInstance = null;

document.addEventListener("DOMContentLoaded", () => {
    carregarTudo();
});

async function carregarTudo() {
    await carregarOpcoes();
    await carregarAtivos();
    await carregarEstatisticas();
}

async function carregarOpcoes() {
    try {
        const response = await fetch(`${API_URL}/opcoes`);
        if (!response.ok) throw new Error("Erro ao carregar opções");
        const data = await response.json();

        // Popula os selects do modal
        const selectTipo = document.getElementById("cad-tipo");
        if (selectTipo) {
            selectTipo.innerHTML = '<option value="">Selecione o Tipo...</option>' +
                data.tipos.map(t => `<option value="${t}">${t}</option>`).join("");
        }

        const selectLocalidade = document.getElementById("cad-localidade");
        if (selectLocalidade) {
            selectLocalidade.innerHTML = '<option value="">Selecione a Localidade...</option>' +
                data.localidades.map(l => `<option value="${l}">${l}</option>`).join("");
        }

        // Popula os menus da Sidebar
        const menuTipos = document.getElementById("menu-tipos");
        if (menuTipos) {
            menuTipos.innerHTML = `<li class="${filtroTipoAtual === 'todos' ? 'active' : ''}" onclick="filtrarPorTipo('todos', this)">📂 Todos os Tipos</li>` +
                data.tipos.map(t => `<li class="${filtroTipoAtual === t ? 'active' : ''}" onclick="filtrarPorTipo('${t}', this)">• ${t}</li>`).join("");
        }

        const menuLocalidades = document.getElementById("menu-localidades");
        if (menuLocalidades) {
            menuLocalidades.innerHTML = `<li class="${filtroLocalidadeAtual === 'todas' ? 'active' : ''}" onclick="filtrarPorLocalidade('todas', this)">🏢 Todas as Localidades</li>` +
                data.localidades.map(l => `<li class="${filtroLocalidadeAtual === l ? 'active' : ''}" onclick="filtrarPorLocalidade('${l}', this)">• ${l}</li>`).join("");
        }
    } catch (err) {
        console.error("Erro em carregarOpcoes:", err);
    }
}

async function carregarAtivos() {
    try {
        const termoBusca = document.getElementById("campo-busca")?.value || "";
        const url = new URL(`${API_URL}/ativos`);
        if (filtroTipoAtual !== "todos") url.searchParams.append("tipo", filtroTipoAtual);
        if (filtroLocalidadeAtual !== "todas") url.searchParams.append("localidade", filtroLocalidadeAtual);
        if (termoBusca) url.searchParams.append("busca", termoBusca);

        const response = await fetch(url);
        if (!response.ok) throw new Error("Erro ao buscar ativos");
        const ativos = await response.json();

        renderizarTabela(ativos);
        atualizarGraficos(ativos);
    } catch (err) {
        console.error("Erro em carregarAtivos:", err);
    }
}

async function carregarEstatisticas() {
    try {
        const response = await fetch(`${API_URL}/stats`);
        if (!response.ok) throw new Error("Erro ao buscar estatísticas");
        const stats = await response.json();

        document.getElementById("stat-total").innerText = stats.total;
        document.getElementById("stat-uso").innerText = stats.uso;
        document.getElementById("stat-estoque").innerText = stats.estoque;
        document.getElementById("stat-manutencao").innerText = stats.manutencao;
    } catch (err) {
        console.error("Erro em carregarEstatisticas:", err);
    }
}

function renderizarTabela(ativos) {
    const tbody = document.getElementById("tabela-corpo");
    if (!tbody) return;

    if (ativos.length === 0) {
        tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; padding: 24px; color: #64748b;">Nenhum ativo encontrado.</td></tr>`;
        return;
    }

    tbody.innerHTML = ativos.map(item => {
        let badgeClass = "badge-estoque";
        if (item.status === "Em Uso") badgeClass = "badge-uso";
        else if (item.status === "Em Manutenção") badgeClass = "badge-manutencao";
        else if (item.status === "Descartado") badgeClass = "badge-descartado";

        return `
            <tr>
                <td>
                    <strong>${item.patrimonio || 'S/P'}</strong><br>
                    <span class="text-muted">${item.numero_serie}</span>
                </td>
                <td>
                    <strong>${item.nome_ativo || item.modelo || 'Sem Nome'}</strong><br>
                    <span class="text-muted">${item.fabricante || '-'}</span>
                </td>
                <td><span class="tag-tipo">${item.tipo || item.categoria}</span></td>
                <td>
                    ${item.localidade || item.localizacao}<br>
                    <span class="text-muted">${item.localizacao_setor || '-'}</span>
                </td>
                <td>
                    ${item.usuario_atual || 'Não atribuído'}<br>
                    <span class="text-muted">${item.centro_custo_atual || '-'}</span>
                </td>
                <td><span class="badge ${badgeClass}">${item.status}</span></td>
                <td>${item.data_movimentacao || '-'}</td>
                <td style="text-align: center;">
                    <button class="btn-icon" title="Editar" onclick="editarAtivo(${item.id})">✏️</button>
                    <button class="btn-icon" title="Excluir" onclick="deletarAtivo(${item.id})">🗑️</button>
                </td>
            </tr>
        `;
    }).join("");
}

function atualizarGraficos(ativos) {
    const statusCounts = {};
    const localidadeCounts = {};

    ativos.forEach(a => {
        statusCounts[a.status] = (statusCounts[a.status] || 0) + 1;
        const loc = a.localidade || a.localizacao || "Indefinido";
        localidadeCounts[loc] = (localidadeCounts[loc] || 0) + 1;
    });

    const ctxStatus = document.getElementById("chartStatus")?.getContext("2d");
    if (ctxStatus) {
        if (chartStatusInstance) chartStatusInstance.destroy();
        chartStatusInstance = new Chart(ctxStatus, {
            type: "doughnut",
            data: {
                labels: Object.keys(statusCounts),
                datasets: [{
                    data: Object.values(statusCounts),
                    backgroundColor: ["#16a34a", "#2563eb", "#d97706", "#dc2626"]
                }]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });
    }

    const ctxLocal = document.getElementById("chartLocalizacao")?.getContext("2d");
    if (ctxLocal) {
        if (chartLocalizacaoInstance) chartLocalizacaoInstance.destroy();
        chartLocalizacaoInstance = new Chart(ctxLocal, {
            type: "bar",
            data: {
                labels: Object.keys(localidadeCounts),
                datasets: [{
                    label: "Ativos",
                    data: Object.values(localidadeCounts),
                    backgroundColor: "#0284c7"
                }]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });
    }
}

function filtrarPorTipo(tipo, elemento) {
    filtroTipoAtual = tipo;
    document.querySelectorAll("#menu-tipos li").forEach(li => li.classList.remove("active"));
    if (elemento) elemento.classList.add("active");
    carregarAtivos();
}

function filtrarPorLocalidade(localidade, elemento) {
    filtroLocalidadeAtual = localidade;
    document.querySelectorAll("#menu-localidades li").forEach(li => li.classList.remove("active"));
    if (elemento) elemento.classList.add("active");
    carregarAtivos();
}

function executarBusca() {
    carregarAtivos();
}

function abrirModalAtivo() {
    document.getElementById("form-ativo").reset();
    document.getElementById("ativo-id").value = "";
    document.getElementById("modal-titulo").innerText = "Novo Ativo";
    document.getElementById("modal-ativo").classList.add("active");
}

function fecharModalAtivo() {
    document.getElementById("modal-ativo").classList.remove("active");
}

function abrirModalAuxiliar() {
    document.getElementById("modal-auxiliar").classList.add("active");
}

function fecharModalAuxiliar() {
    document.getElementById("modal-auxiliar").classList.remove("active");
}

// CARREGA DADOS DO ATIVO PARA EDICAO NO MODAL
async function editarAtivo(id) {
    try {
        const response = await fetch(`${API_URL}/ativos`);
        const ativos = await response.json();
        const ativo = ativos.find(a => a.id === id);

        if (!ativo) {
            alert("Ativo não encontrado!");
            return;
        }

        document.getElementById("ativo-id").value = ativo.id;
        document.getElementById("cad-data").value = ativo.data_movimentacao || "";
        document.getElementById("cad-serie").value = ativo.numero_serie || "";
        document.getElementById("cad-patrimonio").value = ativo.patrimonio || "";
        document.getElementById("cad-ativo").value = ativo.nome_ativo || ativo.modelo || "";
        document.getElementById("cad-fabricante").value = ativo.fabricante || "";
        document.getElementById("cad-tipo").value = ativo.tipo || ativo.categoria || "";
        document.getElementById("cad-localidade").value = ativo.localidade || ativo.localizacao || "";
        document.getElementById("cad-setor").value = ativo.localizacao_setor || "";
        document.getElementById("cad-status").value = ativo.status || "Em Estoque";
        document.getElementById("cad-contrato").value = ativo.contrato || "";
        document.getElementById("cad-user-antigo").value = ativo.usuario_antigo || "";
        document.getElementById("cad-cc-antigo").value = ativo.centro_custo_antigo || "";
        document.getElementById("cad-user-atual").value = ativo.usuario_atual || "";
        document.getElementById("cad-cc-atual").value = ativo.centro_custo_atual || "";
        document.getElementById("cad-resp-cc").value = ativo.responsavel_cc || "";
        document.getElementById("cad-observacoes").value = ativo.observacoes || "";

        document.getElementById("modal-titulo").innerText = "Editar Ativo";
        document.getElementById("modal-ativo").classList.add("active");
    } catch (err) {
        console.error("Erro ao carregar ativo para edição:", err);
    }
}

// SALVA ATIVO (CRA NOVO COM 'POST' OU EDITA EXISTENTE COM 'PUT')
async function salvarAtivo(event) {
    event.preventDefault();

    const id = document.getElementById("ativo-id").value;

    const payload = {
        data_movimentacao: document.getElementById("cad-data").value,
        numero_serie: document.getElementById("cad-serie").value,
        patrimonio: document.getElementById("cad-patrimonio").value,
        nome_ativo: document.getElementById("cad-ativo").value,
        fabricante: document.getElementById("cad-fabricante").value,
        tipo: document.getElementById("cad-tipo").value,
        localidade: document.getElementById("cad-localidade").value,
        localizacao_setor: document.getElementById("cad-setor").value,
        status: document.getElementById("cad-status").value,
        contrato: document.getElementById("cad-contrato").value,
        usuario_antigo: document.getElementById("cad-user-antigo").value,
        centro_custo_antigo: document.getElementById("cad-cc-antigo").value,
        usuario_atual: document.getElementById("cad-user-atual").value,
        centro_custo_atual: document.getElementById("cad-cc-atual").value,
        responsavel_cc: document.getElementById("cad-resp-cc").value,
        observacoes: document.getElementById("cad-observacoes").value
    };

    const url = id ? `${API_URL}/ativos/${id}` : `${API_URL}/ativos`;
    const method = id ? "PUT" : "POST";

    try {
        const response = await fetch(url, {
            method: method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        if (!response.ok) throw new Error("Erro ao salvar ativo");

        fecharModalAtivo();
        carregarTudo();
    } catch (err) {
        alert("Falha ao salvar o ativo. Verifique os campos e tente novamente.");
        console.error(err);
    }
}

async function deletarAtivo(id) {
    if (!confirm("Tem certeza que deseja excluir este ativo?")) return;

    try {
        const response = await fetch(`${API_URL}/ativos/${id}`, { method: "DELETE" });
        if (!response.ok) throw new Error("Erro ao excluir ativo");
        carregarTudo();
    } catch (err) {
        alert("Erro ao excluir ativo.");
        console.error(err);
    }
}

async function adicionarNovoTipo() {
    const input = document.getElementById("novo-tipo-nome");
    const nome = input.value.trim();
    if (!nome) return;

    try {
        const response = await fetch(`${API_URL}/tipos`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ nome })
        });

        if (!response.ok) throw new Error("Erro ao adicionar tipo");

        input.value = "";
        alert("Tipo adicionado com sucesso!");
        carregarOpcoes();
    } catch (err) {
        alert("Erro ao adicionar tipo. Pode ser um nome duplicado.");
        console.error(err);
    }
}

async function adicionarNovaLocalidade() {
    const input = document.getElementById("nova-localidade-nome");
    const nome = input.value.trim();
    if (!nome) return;

    try {
        const response = await fetch(`${API_URL}/localidades`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ nome })
        });

        if (!response.ok) throw new Error("Erro ao adicionar localidade");

        input.value = "";
        alert("Localidade adicionada com sucesso!");
        carregarOpcoes();
    } catch (err) {
        alert("Erro ao adicionar localidade. Pode ser um nome duplicado.");
        console.error(err);
    }
}